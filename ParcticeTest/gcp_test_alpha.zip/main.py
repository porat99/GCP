
import json
from random import sample,shuffle
from tkinter import E


Oopnion=["A", "B", "C", "D"]
filepath= "ques.json"
filepath2="GCP/ParcticeTest/ques.json"
file= open(filepath2,"r")
data= json.load(file)

def get_test(data,num):
    Oopnion=["A", "B", "C", "D"]
    opnion=["A", "B", "C", "D"]
    testQuestion= sample(data,k=num)
    for temp in testQuestion:
        temp2=temp
        
        qes,ansers=temp2.popitem()
        ques=f"{qes}\n"
        shuffle(opnion)
        for op,order in zip(opnion,Oopnion) :
            ques+=f"{order}. {ansers[op]}\n"   
        ans=Oopnion[opnion.index(ansers['Anser'])] 
        yield ques,ans

def start_test(data,ques_amount,isshow):
    try:
        mytest= get_test(data,ques_amount)
        ques_number=0
        right_answer=0
        Mistake_arr=[]
        for test,ans in mytest:
            ques_number+=1
            temp=test.split('?')
            print ("\nquestion",ques_number,"\n",u"\u001b[36m",temp[0],"\u001b[0m",temp[1])
            asnser= input("aswer:").upper()
            while asnser not in Oopnion:asnser= input("aswer:").upper()
            if ans==asnser: right_answer+=1 
            else: 
                Mistake_arr.append({test:[ans,asnser]})
            if isshow:
                print(f"right_answer is -{ans} ")
                input("enter any key to continue")
        ##
        score=(right_answer/ques_amount)*100
        if score<70:color="31m"
        elif 80>score>70:color="33m"
        elif 90>score>80:color="34m"
        else :color="32m"
            
        print(f"\u001b[{color}------------------------------------------------end------------------------------------------------")
        print (f"\n\nwell done you finish the test \nyour answer right {right_answer} from {ques_amount} and scoreing {score}\n\n\n")
        print(u"\u001b[0m \u001b[31m")
        [print(list(i.keys())[0],"\n right answer is ",list(i.values())[0][0],"your answer was ",list(i.values())[0][1],end="\n\n\n") for i in Mistake_arr]
        
    except:
        print("------------------------------------------------end with eror------------------------------------------------")
        print (f"\n\nwell done you finish the test \nyour answer right {right_answer} from {ques_number} and scoreing {(right_answer/ques_number)*100}\n\n\n ")
        [print(list(i.keys())[0],"\n right answer is ",list(i.values())[0][0],"your answer was ",list(i.values())[0][1],end="\n\n\n") for i in Mistake_arr]
        
def main():
    input_options=["1","2"]
    print(f"welcome to gcpTest beta \nwe have {len(data)} questions \nenter 1 to show anser after ech questions \nenter 2 to show only scoring at the and ")
    
    user_input= input("enter choice:")
    while user_input not in input_options:user_input=input("enter choice:")
    if user_input == "1":
        print("choose questions amount")
        amount = input("enter amount:")
        while not amount.isdecimal() or not 0<int(amount)<len(data):amount = input("enter amount:") 
        isshow=True
    elif user_input == "2":
        print("choose questions amount")
        amount = input("enter amount:")
        while not amount.isdecimal() or not 0<int(amount)<len(data):amount = input("enter amount:") 
        isshow=False
    start_test(data,int(amount),isshow)
    

#main function    
if __name__=="__main__":
    main()